/**
 * @file student.h
 * @author Rachel Dennis
 * @date 2022-04-12
 * @brief student library for managing students, including student type definition 
 *        and student functions.
 *
 */ 

/**
* student type stores a student with fields first name, last name, id, grades and num of grades.
*
*/
typedef struct _student 
{ 
  char first_name[50];/**< the students's first name */
  char last_name[50];/**< the students's last name */
  char id[11];/**< the the students's id */
  double *grades; /**< the students's grades */
  int num_grades; /**< the students's num of grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
