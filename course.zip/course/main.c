/**
 * @mainpage MATH101 Class Information
 *  @file main.c
 * @author Rachel Dennis (dennir2@mcmaster.ca)
 * @brief This function provides information to the user of the Top Student of the class,
 * the number of students passing the class and providing all the names of the students who passed.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * Creates an allocated array to store stident scores for MATH101 and returns to user
 * the Top student, Total passing, and Passing students of the class.
 * - There is an allocated array all initialized to zero for the students in MATH101
 * - have function enroll_student to enroll students to the class
 * - last for loop to print students who passed from Student pointer passing_students
 */
int main()
{
  // seed random number generator used to populate the array
  srand((unsigned) time(NULL));

  //Creates a Course allocated array that are all initialized to zero represented by a pointer MATH101.
  Course *MATH101 = calloc(1, sizeof(Course));
  //copies the string value of MATH101 pointed to name of the linked list
  strcpy(MATH101->name, "Basics of Mathematics");
  //copies the string value of MATH101 pointed to code of the linked list
  strcpy(MATH101->code, "MATH 101");

  //for loop to enroll random student to MATH101
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  //prints MATH101
  print_course(MATH101);

  //creates Student type pointer
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);//prints top student

  //creates int variable stores total num of students passing
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);//creates Student type variable to store all students that passed
  printf("\nTotal passing: %d\n", total_passing);//print total passing
  printf("\nPassing students:\n\n");//print passing students with below for loop
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}