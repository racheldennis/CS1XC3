/**
 * @file course.h
 * @author RacheL Dennis
 * @date 2022-04-12
 * @brief Course library for managing courses, including course type definition 
 *        and course functions.
 *
 */
#include "student.h"
#include <stdbool.h>
/**
* course type stores a course with fields name, code, total students.
*
*/
typedef struct _course 
{
  char name[100];/**< the course's name */
  char code[10];/**< the course's code */
  Student *students;
  int total_students;/**< the course's total students */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


